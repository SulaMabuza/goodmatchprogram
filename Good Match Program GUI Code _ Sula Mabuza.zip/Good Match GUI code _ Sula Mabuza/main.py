from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import ObjectProperty
from kivy.lang import Builder
from kivy.core.window import Window #to be able to change app color
from kivy.uix.image import Image #allows the use of image
from kivy.core.window import Window

# Good Match Program GUI by Sula Mabuza for Derivco (Pty) Ltd
#setting the size of the window
Window.size = (500, 700) #(width,height)

Builder.load_file("goodmatchprogram.kv")

# just defining the class for grid layout
class MyGridLayout(Widget):
    # these are out objects from the .kv file
    firstname = ObjectProperty(None)
    secondname = ObjectProperty(None)
    result = ObjectProperty(None)
    # reference this function in the .kv for it to work
    def press(self):
        firstname = self.firstname.text
        secondname = self.secondname.text
        result = self.result.text
        self.firstname.text = firstname
        self.secondname.text = secondname
        verify_names(firstname, secondname)
        self.result.text = f'{name_one} matches {name_two} {percent_str}%, {goodMatch} !'

def sumLists(value_countList):
    #this function does the computation to check if two people are a match or not
    sum = 0
    sumList = []
    global toworkwith
    global goodMatch
    toworkwith = sumList
    global percent_str
    while(len(value_countList)> 1):
        sum = value_countList[0] + value_countList[-1]
        sumList.append(sum)
        #print(sumList)
        if len(sumList) == 3 or len(sumList) == 4:
            toworkwith = sumList

        value_countList.pop(0)
        value_countList.pop(-1)

    if len(value_countList) == 1:
        sumList.append(value_countList[0])
    #print(sumList)
    #print(len(toworkwith))
    if len(toworkwith) == 3:
        answer = toworkwith[0] + toworkwith[2]
        answerList = []
        if answer >= 10:
            for digit in str(answer):
                answerList.append(int(digit))

        else:
            answerList.append(answer)
        answerList.append(toworkwith[1])
        percent_str = str(answerList[0] + answerList[-1]) + str(answerList[1])

        if int(percent_str) > 100:
            dummy_list = []
            for digit in percent_str:
                dummy_list.append(int(digit))
            percent_str = str(dummy_list[0] + dummy_list[-1]) + str(dummy_list[1])

        if int(percent_str) >= 80:
            goodMatch = "Good Match"
            print(f'{name_one} matches {name_two} {percent_str}%, good match')
        else:
            goodMatch = ""
            print(f'{name_one} matches {name_two} {percent_str}%')
    if len(toworkwith) == 4:
        answer = toworkwith[0] + toworkwith[-1]
        answer2 = toworkwith[1] + toworkwith[-2]
        answerList= []
        if answer >= 10:
            for digit in str(answer):
                answerList.append(int(digit))

        else:
            answerList.append(answer)

        if answer2 >= 10:
            for digit in str(answer2):
                answerList.append(int(digit))

        else:
            answerList.append(answer2)

        percent_str = str(answerList[0] + answerList[-1]) + str(answerList[1])

        if int(percent_str) > 100:
            dummy_list = []
            for digit in percent_str:
                dummy_list.append(int(digit))
            percent_str = str(dummy_list[0] + dummy_list[-1]) + str(dummy_list[1])

        if int(percent_str) >= 80:
            goodMatch = "Good Match"
            print(f'{name_one} matches {name_two} {percent_str}%, good match')

        else:
            goodMatch = ''
            print(f'{name_one} matches {name_two} {percent_str}%')


    return sumList

def verify_names(firstname, secondname):
    # this function checks first if the names inserted are alphabets before calling the function for computation
    global name_one
    global name_two
    global name1
    global name2
    name1 = firstname
    name2 = secondname
    name_one = firstname
    name_two = secondname
    bool = 0
    for character in name1 and name2:
        if not character.isalpha():
            print("names are invalid, please check, should be alphabets")
        else:
            bool = 1
    if bool:
        twoStrings()

def twoStrings():
    #this function breaks down the name strings into character lists before doing the cancellation that gives int values
    print(f'Hello {name1} and {name2}')
    default_word = 'matches'.upper()
    name2_word = name2.upper()
    default_wordList = list(default_word)
    default_string = name1 + 'matches' + name2
    toCompareString = default_string.upper()
    name1List = list(name1.upper())
    name2List = list(name2.upper())
    compareList = list(toCompareString.upper())
    value_countList = [0]

    #start with the first string = Jack
    for i in range(0, len(name1List)):
        value_countList.append(toCompareString.count(name1List[i]))
        toCompareString = toCompareString.replace(name1List[i], '')
        default_word = default_word.replace(name1List[i], '')
        name2_word = name2_word.replace(name1List[i], '')
        default_wordList = list(default_word)
        name2List = list(name2_word)

    value_countList.remove(value_countList[0])

    for i in range(0, len(default_wordList)):
        value_countList.append(toCompareString.count(default_wordList[i]))
        toCompareString = toCompareString.replace(default_wordList[i], '')
        name2_word = name2_word.replace(default_wordList[i], '')
        name2List = list(name2_word)

    for i in range(0, len(name2List)-1):
        value_countList.append(toCompareString.count(name2List[i]))
        toCompareString = toCompareString.replace(name2List[i], '')

    sumList = sumLists(value_countList)
    #sumLists(sumList)
    for i in range (0, 1):
        sumLists(sumList)

class GoodMatchApp(App):
    def build(self):
        # return Label(text="Hello World", font_size=72)
        #Window.clearcolor = (1,1,1,1) #changes the color
        #can be overridden in the kv file
        return MyGridLayout()

if __name__ == '__main__':
    GoodMatchApp().run()

